package com.boomer.rider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
